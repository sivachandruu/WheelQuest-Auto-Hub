import {
  Upload,
  MapPin,
  Calendar,
  Wrench,
  FileCheck,
  Award,
  TrendingUp,
  CheckCircle,
  Shield,
} from 'lucide-react';

interface VerificationProps {
  onNavigate: (page: string) => void;
}

export function Verification({ onNavigate }: VerificationProps) {
  const verificationSteps = [
    {
      icon: Upload,
      title: 'Upload Car Details',
      description: 'Submit your car information including model, year, photos, and VIN number.',
      details: [
        'High-quality photos from multiple angles',
        'Complete vehicle registration documents',
        'VIN (Vehicle Identification Number)',
        'Ownership and insurance details',
      ],
    },
    {
      icon: MapPin,
      title: 'Find Nearby Workshop',
      description: 'Our system recommends certified workshops near your location.',
      details: [
        'View workshop profiles and ratings',
        'Check available services',
        'Compare prices and reviews',
        'Select preferred workshop',
      ],
    },
    {
      icon: Calendar,
      title: 'Book Scanning Appointment',
      description: 'Schedule a convenient time for your vehicle inspection.',
      details: [
        'Choose available date and time slots',
        'Receive instant confirmation',
        'Get appointment reminders',
        'Flexible rescheduling options',
      ],
    },
    {
      icon: Wrench,
      title: 'OBD-II Diagnostic Scan',
      description: 'Certified technician performs comprehensive vehicle diagnostic.',
      details: [
        'Professional OBD-II scanner equipment',
        'Complete DTC fault code detection',
        '200+ point vehicle inspection',
        'Real-time diagnostic report generation',
      ],
    },
    {
      icon: FileCheck,
      title: 'Technician Uploads Report',
      description: 'Detailed scan report linked to your VIN for transparency.',
      details: [
        'Complete diagnostic codes (DTC)',
        'Technical notes and observations',
        'Photo evidence of inspection',
        'Condition rating and recommendations',
      ],
    },
    {
      icon: Award,
      title: 'Workshop Certification',
      description: 'Car marked as verified with official workshop certification.',
      details: [
        'Digital verification badge',
        'Tamper-proof certificate',
        'Linked to workshop credentials',
        'Valid for 6 months',
      ],
    },
    {
      icon: TrendingUp,
      title: 'Increased Value & Trust',
      description: 'Verified cars attract 40% more buyers and command premium prices.',
      details: [
        '15-20% higher resale value',
        'Faster sale completion',
        'Reduced negotiation hassles',
        'Enhanced buyer confidence',
      ],
    },
  ];

  const verificationBenefits = [
    {
      icon: Shield,
      title: 'Complete Transparency',
      description: 'Full diagnostic report accessible to all potential buyers',
    },
    {
      icon: CheckCircle,
      title: 'Certified Quality',
      description: 'Verified by certified workshops with professional equipment',
    },
    {
      icon: TrendingUp,
      title: 'Premium Pricing',
      description: 'Command 15-20% higher prices for verified vehicles',
    },
    {
      icon: Award,
      title: 'Trust Badge',
      description: 'Display official OBD-II verified badge on your listing',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Shield className="h-20 w-20 mx-auto mb-6" />
          <h1 className="text-5xl font-bold mb-6">Vehicle Verification System</h1>
          <p className="text-xl max-w-3xl mx-auto mb-8">
            Our proprietary 7-step OBD-II verification process ensures complete transparency and builds
            trust between buyers and sellers.
          </p>
          <button
            onClick={() => onNavigate('sell-car')}
            className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-lg inline-flex items-center space-x-2"
          >
            <Upload className="h-5 w-5" />
            <span>Start Verification Process</span>
          </button>
        </div>
      </div>

      <div className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">7 simple steps to get your car verified</p>
          </div>

          <div className="space-y-12">
            {verificationSteps.map((step, index) => (
              <div
                key={index}
                className={`flex flex-col md:flex-row gap-8 items-start ${
                  index % 2 === 1 ? 'md:flex-row-reverse' : ''
                }`}
              >
                <div className="flex-shrink-0">
                  <div className="bg-blue-600 text-white w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold shadow-lg">
                    {index + 1}
                  </div>
                </div>

                <div className="flex-1 bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-shadow">
                  <div className="flex items-start space-x-4">
                    <div className="bg-blue-100 p-4 rounded-xl">
                      <step.icon className="h-8 w-8 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-gray-900 mb-3">{step.title}</h3>
                      <p className="text-gray-600 mb-4">{step.description}</p>
                      <ul className="space-y-2">
                        {step.details.map((detail, i) => (
                          <li key={i} className="flex items-start space-x-2 text-sm text-gray-700">
                            <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                            <span>{detail}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Get Verified?</h2>
            <p className="text-xl text-gray-600">The benefits speak for themselves</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {verificationBenefits.map((benefit, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-blue-50 to-white rounded-xl p-6 border border-blue-100 hover:shadow-lg transition-shadow text-center"
              >
                <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <benefit.icon className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="py-20 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">What Gets Verified?</h2>
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
              {[
                'Engine Performance & Health',
                'Transmission System Check',
                'Emission Control System',
                'ABS & Braking System',
                'Airbag & Safety Systems',
                'Battery & Electrical System',
                'Fuel System Efficiency',
                'Oxygen Sensors',
                'Catalytic Converter',
                'Ignition System',
                'Cooling System',
                'Complete DTC Fault Codes',
              ].map((item, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="py-20 bg-gradient-to-br from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Get Your Car Verified?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Increase your car's value and sell faster with our trusted verification system
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <button
              onClick={() => onNavigate('sell-car')}
              className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-lg"
            >
              List & Verify Your Car
            </button>
            <button
              onClick={() => onNavigate('workshops')}
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors text-lg"
            >
              Find Workshops
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
