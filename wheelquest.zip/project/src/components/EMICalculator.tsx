import { useState } from 'react';
import { Calculator, TrendingUp, DollarSign } from 'lucide-react';

export function EMICalculator() {
  const [loanAmount, setLoanAmount] = useState(500000);
  const [interestRate, setInterestRate] = useState(8.5);
  const [tenure, setTenure] = useState(5);
  const [emi, setEmi] = useState(0);
  const [totalInterest, setTotalInterest] = useState(0);
  const [totalAmount, setTotalAmount] = useState(0);

  const calculateEMI = () => {
    const principal = loanAmount;
    const ratePerMonth = interestRate / 12 / 100;
    const numberOfMonths = tenure * 12;

    const emiValue =
      (principal * ratePerMonth * Math.pow(1 + ratePerMonth, numberOfMonths)) /
      (Math.pow(1 + ratePerMonth, numberOfMonths) - 1);

    const totalAmountPayable = emiValue * numberOfMonths;
    const totalInterestPayable = totalAmountPayable - principal;

    setEmi(Math.round(emiValue));
    setTotalInterest(Math.round(totalInterestPayable));
    setTotalAmount(Math.round(totalAmountPayable));
  };

  useState(() => {
    calculateEMI();
  });

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Calculator className="h-16 w-16 text-blue-600 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Car Loan EMI Calculator</h1>
          <p className="text-xl text-gray-600">Calculate your monthly payments and plan your budget</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Loan Details</h2>

            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-gray-700">Loan Amount</label>
                  <span className="text-sm font-bold text-blue-600">₹{loanAmount.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min="100000"
                  max="5000000"
                  step="50000"
                  value={loanAmount}
                  onChange={(e) => {
                    setLoanAmount(parseInt(e.target.value));
                    calculateEMI();
                  }}
                  className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>₹1L</span>
                  <span>₹50L</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-gray-700">Interest Rate (per annum)</label>
                  <span className="text-sm font-bold text-blue-600">{interestRate}%</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="20"
                  step="0.1"
                  value={interestRate}
                  onChange={(e) => {
                    setInterestRate(parseFloat(e.target.value));
                    calculateEMI();
                  }}
                  className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>5%</span>
                  <span>20%</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-gray-700">Loan Tenure</label>
                  <span className="text-sm font-bold text-blue-600">{tenure} years</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="7"
                  step="1"
                  value={tenure}
                  onChange={(e) => {
                    setTenure(parseInt(e.target.value));
                    calculateEMI();
                  }}
                  className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>1 year</span>
                  <span>7 years</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl shadow-xl p-8 text-white">
            <h2 className="text-2xl font-bold mb-8">Your EMI Breakdown</h2>

            <div className="space-y-6">
              <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-6">
                <div className="flex items-center space-x-3 mb-2">
                  <DollarSign className="h-6 w-6" />
                  <p className="text-sm opacity-90">Monthly EMI</p>
                </div>
                <p className="text-4xl font-bold">₹{emi.toLocaleString()}</p>
              </div>

              <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-6">
                <div className="flex items-center space-x-3 mb-2">
                  <Calculator className="h-6 w-6" />
                  <p className="text-sm opacity-90">Principal Amount</p>
                </div>
                <p className="text-2xl font-bold">₹{loanAmount.toLocaleString()}</p>
              </div>

              <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-6">
                <div className="flex items-center space-x-3 mb-2">
                  <TrendingUp className="h-6 w-6" />
                  <p className="text-sm opacity-90">Total Interest</p>
                </div>
                <p className="text-2xl font-bold">₹{totalInterest.toLocaleString()}</p>
              </div>

              <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-6">
                <div className="flex items-center space-x-3 mb-2">
                  <DollarSign className="h-6 w-6" />
                  <p className="text-sm opacity-90">Total Amount Payable</p>
                </div>
                <p className="text-2xl font-bold">₹{totalAmount.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
          <h3 className="font-bold text-gray-900 mb-3">Important Notes:</h3>
          <ul className="space-y-2 text-sm text-gray-700">
            <li>• The EMI calculation is approximate and for reference purposes only</li>
            <li>• Actual EMI may vary based on bank policies and processing fees</li>
            <li>• Interest rates are subject to change based on RBI guidelines</li>
            <li>• Down payment requirements vary between 10-30% of car value</li>
            <li>• Additional charges like processing fees, insurance may apply</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
