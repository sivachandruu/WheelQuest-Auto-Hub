import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Homepage } from './components/Homepage';
import { SignIn } from './components/SignIn';
import { SignUp } from './components/SignUp';
import { SellCar } from './components/SellCar';
import { UsedCars } from './components/UsedCars';
import { Verification } from './components/Verification';
import { UserDashboard } from './components/UserDashboard';
import { EMICalculator } from './components/EMICalculator';
import { Workshops } from './components/Workshops';

function AppContent() {
  const [currentPage, setCurrentPage] = useState('home');
  const { loading } = useAuth();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">Loading WheelQuest AutoHub...</p>
        </div>
      </div>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Homepage onNavigate={setCurrentPage} />;
      case 'signin':
        return <SignIn onNavigate={setCurrentPage} />;
      case 'signup':
        return <SignUp onNavigate={setCurrentPage} />;
      case 'sell-car':
        return <SellCar onNavigate={setCurrentPage} />;
      case 'used-cars':
      case 'new-cars':
        return <UsedCars />;
      case 'verification':
        return <Verification onNavigate={setCurrentPage} />;
      case 'user-dashboard':
      case 'workshop-dashboard':
        return <UserDashboard onNavigate={setCurrentPage} />;
      case 'emi-calculator':
        return <EMICalculator />;
      case 'workshops':
        return <Workshops />;
      case 'compare':
        return (
          <div className="min-h-screen bg-gray-50 py-20 px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">Compare Cars</h1>
              <p className="text-gray-600">Feature coming soon!</p>
            </div>
          </div>
        );
      case 'news':
        return (
          <div className="min-h-screen bg-gray-50 py-20 px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">Car News & Tips</h1>
              <p className="text-gray-600">Feature coming soon!</p>
            </div>
          </div>
        );
      default:
        return <Homepage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {currentPage !== 'signin' && currentPage !== 'signup' && (
        <Navbar onNavigate={setCurrentPage} currentPage={currentPage} />
      )}
      <main className={currentPage !== 'signin' && currentPage !== 'signup' ? 'pt-16' : ''}>
        {renderPage()}
      </main>
      {currentPage !== 'signin' && currentPage !== 'signup' && (
        <Footer onNavigate={setCurrentPage} />
      )}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
