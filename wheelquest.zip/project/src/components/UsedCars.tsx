import { useState, useEffect } from 'react';
import { Search, SlidersHorizontal, CheckCircle, MapPin } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Car } from '../types';

export function UsedCars() {
  const [cars, setCars] = useState<Car[]>([]);
  const [filteredCars, setFilteredCars] = useState<Car[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBrand, setFilterBrand] = useState('');
  const [filterVerified, setFilterVerified] = useState(false);

  useEffect(() => {
    fetchCars();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [cars, searchTerm, filterBrand, filterVerified]);

  const fetchCars = async () => {
    const { data, error } = await supabase
      .from('cars')
      .select('*')
      .eq('is_active', true)
      .eq('listing_type', 'used')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching cars:', error);
    } else {
      setCars(data || []);
    }
    setLoading(false);
  };

  const applyFilters = () => {
    let filtered = [...cars];

    if (searchTerm) {
      filtered = filtered.filter(
        (car) =>
          car.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
          car.model.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterBrand) {
      filtered = filtered.filter((car) => car.brand === filterBrand);
    }

    if (filterVerified) {
      filtered = filtered.filter((car) => car.is_verified);
    }

    setFilteredCars(filtered);
  };

  const brands = Array.from(new Set(cars.map((car) => car.brand))).sort();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading cars...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Used Cars</h1>
          <p className="text-gray-600">{filteredCars.length} verified cars available</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search by brand or model..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div>
              <select
                value={filterBrand}
                onChange={(e) => setFilterBrand(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">All Brands</option>
                {brands.map((brand) => (
                  <option key={brand} value={brand}>
                    {brand}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <button
                onClick={() => setFilterVerified(!filterVerified)}
                className={`w-full px-4 py-3 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-colors ${
                  filterVerified
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <SlidersHorizontal className="h-5 w-5" />
                <span>{filterVerified ? 'Verified Only' : 'All Cars'}</span>
              </button>
            </div>
          </div>
        </div>

        {filteredCars.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">No cars found matching your criteria</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCars.map((car) => (
              <div
                key={car.id}
                className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow cursor-pointer group"
              >
                <div className="relative h-48 bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden">
                  {car.images[0] ? (
                    <img
                      src={car.images[0]}
                      alt={`${car.brand} ${car.model}`}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="text-gray-400 text-lg font-semibold">
                        {car.brand} {car.model}
                      </span>
                    </div>
                  )}
                  {car.is_verified && (
                    <div className="absolute top-3 right-3 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center space-x-1 shadow-lg">
                      <CheckCircle className="h-3 w-3" />
                      <span>OBD-II Verified</span>
                    </div>
                  )}
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">
                    {car.brand} {car.model}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">{car.variant || 'Standard'}</p>

                  <div className="grid grid-cols-3 gap-2 text-xs text-gray-600 mb-4">
                    <div className="bg-gray-50 rounded p-2 text-center">
                      <p className="font-semibold text-gray-900">{car.year}</p>
                      <p>Year</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2 text-center">
                      <p className="font-semibold text-gray-900">{car.mileage.toLocaleString()}</p>
                      <p>KM</p>
                    </div>
                    <div className="bg-gray-50 rounded p-2 text-center">
                      <p className="font-semibold text-gray-900">{car.fuel_type}</p>
                      <p>Fuel</p>
                    </div>
                  </div>

                  <div className="flex items-center text-sm text-gray-600 mb-4">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{car.city}</span>
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t border-gray-200">
                    <div>
                      <p className="text-2xl font-bold text-gray-900">₹{(car.price / 100000).toFixed(2)}L</p>
                      {car.ai_estimated_price > 0 && (
                        <p className="text-xs text-green-600">AI Estimated</p>
                      )}
                    </div>
                    <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors font-semibold">
                      View
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
