# WheelQuest AutoHub

A modern, premium automotive marketplace platform with AI-powered price estimation and OBD-II vehicle verification system.

## Features

### Core Functionality

- **Car Marketplace**: Browse and search verified cars with advanced filters
- **AI Price Estimation**: Get accurate car valuations using AI algorithms
- **OBD-II Verification**: 7-step professional vehicle scanning process
- **User Dashboard**: Manage listings, bookings, and verification status
- **Workshop Network**: Certified partner workshops for vehicle diagnostics
- **EMI Calculator**: Calculate loan payments and plan your budget
- **Car Comparison**: Compare multiple vehicles side-by-side
- **News & Tips**: Stay updated with automotive news and maintenance guides

### Key Pages

1. **Homepage**: Hero banner, search, featured cars, how it works, testimonials
2. **Buy Cars**: Browse new and used verified vehicles
3. **Sell Car**: List your vehicle with AI price estimation
4. **Verification**: Learn about our 7-step OBD-II verification process
5. **Workshops**: Find certified partner service centers
6. **User Dashboard**: Manage your cars, bookings, and profile
7. **EMI Calculator**: Financial planning tool
8. **Authentication**: Secure sign-in/sign-up system

## Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS with custom animations
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **Icons**: Lucide React
- **Build Tool**: Vite

## Database Schema

### Tables

- `profiles` - Extended user profiles with roles
- `workshops` - Certified service centers
- `cars` - Vehicle listings with verification status
- `bookings` - Scanning appointment bookings
- `scan_reports` - OBD-II diagnostic reports
- `car_comparisons` - Saved vehicle comparisons
- `testimonials` - Customer reviews
- `car_news` - Blog posts and guides

## Getting Started

### Prerequisites

- Node.js 18+ installed
- Supabase account

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

3. Environment variables are already configured in `.env`

4. Start the development server:
   ```bash
   npm run dev
   ```

5. Build for production:
   ```bash
   npm run build
   ```

## User Roles

- **Buyer**: Browse and purchase verified cars
- **Seller**: List cars with AI price estimation
- **Workshop**: Manage scanning appointments and upload reports
- **Admin**: Platform management and oversight

## Verification Process

### 7-Step OBD-II Verification

1. **Upload Details**: Submit car information, photos, and VIN
2. **Find Workshop**: Browse certified workshops near you
3. **Book Appointment**: Schedule scanning at convenient time
4. **OBD-II Scan**: Professional diagnostic by certified technician
5. **Get Report**: Detailed scan results with DTC fault codes
6. **Workshop Certification**: Car marked as verified
7. **Increased Value**: 15-20% higher resale value with verification badge

## AI Price Estimation

The AI pricing algorithm considers:

- Brand reputation and market demand
- Vehicle age and depreciation rates
- Mileage and usage patterns
- Ownership history
- Fuel type and transmission preferences
- Current market conditions

## Security Features

- Row Level Security (RLS) on all database tables
- Secure authentication with Supabase Auth
- Role-based access control
- Data encryption at rest and in transit

## Sample Accounts

Create an account using the Sign Up page with:
- Email and password
- Full name
- Role selection (Buyer/Seller/Workshop)

## Design Features

- Premium, modern UI with smooth animations
- Fully responsive (mobile, tablet, desktop)
- Professional color scheme with blue accents
- Hover effects and transitions
- Loading states and error handling
- Accessibility considerations

## Future Enhancements

- 360° car view functionality
- Advanced comparison tools
- Booking payment integration
- Mobile app development
- AI chatbot support
- Enhanced analytics dashboard

## License

All rights reserved © 2024 WheelQuest AutoHub

## Support

For support, email support@wheelquest.com or call +91 1800-123-4567
