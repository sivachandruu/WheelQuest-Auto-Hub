/*
  # WheelQuest AutoHub Database Schema

  1. New Tables
    - `profiles`
      - Extended user profile data
      - Links to auth.users
      - Stores role (buyer, seller, workshop, admin)
      
    - `workshops`
      - Registered service centers
      - Location, services offered, ratings
      - Verification status
      
    - `cars`
      - Car listings (new and used)
      - Detailed specifications
      - Verification status and scan reports
      - Pricing and seller information
      
    - `bookings`
      - Scanning appointment bookings
      - Links users, cars, and workshops
      - Status tracking
      
    - `scan_reports`
      - OBD-II scan results
      - DTC fault codes
      - Links to cars and workshops
      - Verification badges
      
    - `car_comparisons`
      - User saved comparisons
      - Up to 3 cars per comparison
      
    - `testimonials`
      - Customer reviews and ratings
      - Featured on homepage
      
    - `car_news`
      - Blog posts about cars
      - Tips and maintenance guides

  2. Security
    - Enable RLS on all tables
    - Policies for authenticated users based on roles
    - Workshop and admin specific policies
*/

-- Profiles table (extends auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  role text NOT NULL DEFAULT 'buyer',
  avatar_url text DEFAULT '',
  location text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Workshops table
CREATE TABLE IF NOT EXISTS workshops (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text DEFAULT '',
  address text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  pincode text NOT NULL,
  phone text NOT NULL,
  email text NOT NULL,
  services text[] DEFAULT '{}',
  rating numeric(3,2) DEFAULT 0,
  total_reviews int DEFAULT 0,
  is_verified boolean DEFAULT false,
  is_active boolean DEFAULT true,
  latitude numeric(10,8) DEFAULT 0,
  longitude numeric(11,8) DEFAULT 0,
  image_url text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE workshops ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view verified workshops"
  ON workshops FOR SELECT
  TO authenticated
  USING (is_verified = true AND is_active = true);

CREATE POLICY "Workshop owners can view own workshop"
  ON workshops FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Workshop owners can update own workshop"
  ON workshops FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can create workshops"
  ON workshops FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Cars table
CREATE TABLE IF NOT EXISTS cars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  vin text UNIQUE,
  brand text NOT NULL,
  model text NOT NULL,
  variant text DEFAULT '',
  year int NOT NULL,
  fuel_type text NOT NULL,
  transmission text NOT NULL,
  mileage int DEFAULT 0,
  owners int DEFAULT 1,
  price numeric(12,2) NOT NULL,
  ai_estimated_price numeric(12,2) DEFAULT 0,
  condition text DEFAULT 'used',
  body_type text DEFAULT '',
  color text DEFAULT '',
  engine_capacity text DEFAULT '',
  power text DEFAULT '',
  torque text DEFAULT '',
  seating_capacity int DEFAULT 5,
  features text[] DEFAULT '{}',
  description text DEFAULT '',
  city text NOT NULL,
  state text NOT NULL,
  images text[] DEFAULT '{}',
  is_verified boolean DEFAULT false,
  verified_by uuid REFERENCES workshops(id),
  verification_date timestamptz,
  is_active boolean DEFAULT true,
  listing_type text DEFAULT 'used',
  views int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cars ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active cars"
  ON cars FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Sellers can view own cars"
  ON cars FOR SELECT
  TO authenticated
  USING (auth.uid() = seller_id);

CREATE POLICY "Sellers can create cars"
  ON cars FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Sellers can update own cars"
  ON cars FOR UPDATE
  TO authenticated
  USING (auth.uid() = seller_id)
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Sellers can delete own cars"
  ON cars FOR DELETE
  TO authenticated
  USING (auth.uid() = seller_id);

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  car_id uuid REFERENCES cars(id) ON DELETE CASCADE,
  workshop_id uuid REFERENCES workshops(id) ON DELETE CASCADE,
  booking_date date NOT NULL,
  booking_time time NOT NULL,
  status text DEFAULT 'pending',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Workshops can view their bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM workshops
      WHERE workshops.id = bookings.workshop_id
      AND workshops.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create bookings"
  ON bookings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Workshops can update their bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM workshops
      WHERE workshops.id = bookings.workshop_id
      AND workshops.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM workshops
      WHERE workshops.id = bookings.workshop_id
      AND workshops.user_id = auth.uid()
    )
  );

-- Scan Reports table
CREATE TABLE IF NOT EXISTS scan_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  car_id uuid REFERENCES cars(id) ON DELETE CASCADE,
  workshop_id uuid REFERENCES workshops(id) ON DELETE CASCADE,
  booking_id uuid REFERENCES bookings(id),
  vin text NOT NULL,
  dtc_codes text[] DEFAULT '{}',
  scan_data jsonb DEFAULT '{}',
  technician_name text NOT NULL,
  technician_notes text DEFAULT '',
  overall_status text DEFAULT 'good',
  report_url text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE scan_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Car owners can view their scan reports"
  ON scan_reports FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cars
      WHERE cars.id = scan_reports.car_id
      AND cars.seller_id = auth.uid()
    )
  );

CREATE POLICY "Anyone can view verified car scan reports"
  ON scan_reports FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM cars
      WHERE cars.id = scan_reports.car_id
      AND cars.is_verified = true
    )
  );

CREATE POLICY "Workshops can create scan reports"
  ON scan_reports FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM workshops
      WHERE workshops.id = scan_reports.workshop_id
      AND workshops.user_id = auth.uid()
    )
  );

-- Car Comparisons table
CREATE TABLE IF NOT EXISTS car_comparisons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  car_ids uuid[] NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE car_comparisons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own comparisons"
  ON car_comparisons FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create comparisons"
  ON car_comparisons FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own comparisons"
  ON car_comparisons FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  user_name text NOT NULL,
  user_avatar text DEFAULT '',
  rating int NOT NULL DEFAULT 5,
  comment text NOT NULL,
  car_id uuid REFERENCES cars(id) ON DELETE SET NULL,
  is_featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view featured testimonials"
  ON testimonials FOR SELECT
  TO authenticated
  USING (is_featured = true);

CREATE POLICY "Users can view own testimonials"
  ON testimonials FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create testimonials"
  ON testimonials FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Car News table
CREATE TABLE IF NOT EXISTS car_news (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  excerpt text DEFAULT '',
  content text NOT NULL,
  author text NOT NULL,
  category text DEFAULT 'news',
  image_url text DEFAULT '',
  tags text[] DEFAULT '{}',
  views int DEFAULT 0,
  is_published boolean DEFAULT true,
  published_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE car_news ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view published news"
  ON car_news FOR SELECT
  TO authenticated
  USING (is_published = true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_cars_brand ON cars(brand);
CREATE INDEX IF NOT EXISTS idx_cars_listing_type ON cars(listing_type);
CREATE INDEX IF NOT EXISTS idx_cars_city ON cars(city);
CREATE INDEX IF NOT EXISTS idx_cars_is_verified ON cars(is_verified);
CREATE INDEX IF NOT EXISTS idx_workshops_city ON workshops(city);
CREATE INDEX IF NOT EXISTS idx_workshops_is_verified ON workshops(is_verified);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_scan_reports_vin ON scan_reports(vin);
