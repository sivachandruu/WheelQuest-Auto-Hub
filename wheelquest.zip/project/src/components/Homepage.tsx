import { useState, useEffect } from 'react';
import {
  Search,
  Shield,
  CheckCircle,
  TrendingUp,
  Users,
  Star,
  ChevronRight,
  Upload,
  MapPin,
  Calendar,
  FileCheck,
  Award,
  Wrench,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Car, Workshop, Testimonial } from '../types';

interface HomepageProps {
  onNavigate: (page: string) => void;
}

export function Homepage({ onNavigate }: HomepageProps) {
  const [searchBrand, setSearchBrand] = useState('');
  const [searchBudget, setSearchBudget] = useState('');
  const [searchLocation, setSearchLocation] = useState('');
  const [featuredCars, setFeaturedCars] = useState<Car[]>([]);
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);

  useEffect(() => {
    fetchFeaturedCars();
    fetchWorkshops();
    fetchTestimonials();
  }, []);

  const fetchFeaturedCars = async () => {
    const { data } = await supabase
      .from('cars')
      .select('*')
      .eq('is_active', true)
      .limit(6)
      .order('created_at', { ascending: false });

    if (data) setFeaturedCars(data);
  };

  const fetchWorkshops = async () => {
    const { data } = await supabase
      .from('workshops')
      .select('*')
      .eq('is_verified', true)
      .limit(4);

    if (data) setWorkshops(data);
  };

  const fetchTestimonials = async () => {
    const { data } = await supabase
      .from('testimonials')
      .select('*')
      .eq('is_featured', true)
      .limit(3);

    if (data) setTestimonials(data);
  };

  const brands = ['Maruti Suzuki', 'Hyundai', 'Tata', 'Mahindra', 'Honda', 'Toyota', 'Kia', 'MG'];
  const budgets = ['Under 5L', '5L - 10L', '10L - 20L', '20L+'];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="relative h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-600 overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-30"></div>
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/1149137/pexels-photo-1149137.jpeg?auto=compress&cs=tinysrgb&w=1920')] bg-cover bg-center opacity-20"></div>

        <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center items-center text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-fade-in">
            Find Your Perfect Ride
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-12 max-w-3xl">
            India's Most Trusted Platform for Verified Cars with OBD-II Scanning & AI Price Estimation
          </p>

          <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-4xl">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <select
                value={searchBrand}
                onChange={(e) => setSearchBrand(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Select Brand</option>
                {brands.map((brand) => (
                  <option key={brand} value={brand}>
                    {brand}
                  </option>
                ))}
              </select>

              <select
                value={searchBudget}
                onChange={(e) => setSearchBudget(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Select Budget</option>
                {budgets.map((budget) => (
                  <option key={budget} value={budget}>
                    {budget}
                  </option>
                ))}
              </select>

              <input
                type="text"
                placeholder="Location"
                value={searchLocation}
                onChange={(e) => setSearchLocation(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />

              <button
                onClick={() => onNavigate('used-cars')}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 font-semibold"
              >
                <Search className="h-5 w-5" />
                <span>Search</span>
              </button>
            </div>

            <div className="flex justify-center space-x-6 mt-6">
              <button
                onClick={() => onNavigate('new-cars')}
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                Browse New Cars
              </button>
              <button
                onClick={() => onNavigate('used-cars')}
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                Verified Used Cars
              </button>
            </div>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-4 gap-6 w-full max-w-4xl">
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-6 text-white">
              <Shield className="h-8 w-8 mb-3" />
              <h3 className="font-bold text-lg mb-1">OBD-II Verified</h3>
              <p className="text-sm text-gray-200">Certified by workshops</p>
            </div>
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-6 text-white">
              <TrendingUp className="h-8 w-8 mb-3" />
              <h3 className="font-bold text-lg mb-1">AI Price Check</h3>
              <p className="text-sm text-gray-200">Get accurate valuations</p>
            </div>
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-6 text-white">
              <CheckCircle className="h-8 w-8 mb-3" />
              <h3 className="font-bold text-lg mb-1">Quality Assured</h3>
              <p className="text-sm text-gray-200">200+ point inspection</p>
            </div>
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-6 text-white">
              <Users className="h-8 w-8 mb-3" />
              <h3 className="font-bold text-lg mb-1">50K+ Users</h3>
              <p className="text-sm text-gray-200">Trusted community</p>
            </div>
          </div>
        </div>
      </div>

      {featuredCars.length > 0 && (
        <div className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center mb-12">
              <div>
                <h2 className="text-4xl font-bold text-gray-900 mb-2">Featured Verified Cars</h2>
                <p className="text-gray-600">Handpicked premium vehicles with full verification</p>
              </div>
              <button
                onClick={() => onNavigate('used-cars')}
                className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold"
              >
                <span>View All</span>
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredCars.map((car) => (
                <div
                  key={car.id}
                  className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow cursor-pointer group"
                  onClick={() => onNavigate('used-cars')}
                >
                  <div className="relative h-48 bg-gray-200 overflow-hidden">
                    {car.images[0] ? (
                      <img
                        src={car.images[0]}
                        alt={`${car.brand} ${car.model}`}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200">
                        <span className="text-gray-400 text-lg font-semibold">
                          {car.brand} {car.model}
                        </span>
                      </div>
                    )}
                    {car.is_verified && (
                      <div className="absolute top-3 right-3 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center space-x-1">
                        <CheckCircle className="h-3 w-3" />
                        <span>Verified</span>
                      </div>
                    )}
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">
                      {car.brand} {car.model}
                    </h3>
                    <p className="text-gray-600 text-sm mb-4">{car.variant}</p>

                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                      <span>{car.year}</span>
                      <span>•</span>
                      <span>{car.mileage.toLocaleString()} km</span>
                      <span>•</span>
                      <span>{car.fuel_type}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-2xl font-bold text-gray-900">
                          ₹{(car.price / 100000).toFixed(2)}L
                        </p>
                        <p className="text-xs text-gray-500">{car.city}</p>
                      </div>
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        View Details
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="py-20 bg-gradient-to-br from-blue-50 to-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How WheelQuest Works</h2>
            <p className="text-xl text-gray-600">Your trusted journey to verified car ownership</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="bg-blue-600 text-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold shadow-lg">
                1
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <Search className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-3">Browse & Select</h3>
                <p className="text-gray-600">
                  Search from thousands of verified cars. Filter by brand, budget, and location to find your perfect match.
                </p>
              </div>
            </div>

            <div className="text-center">
              <div className="bg-blue-600 text-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold shadow-lg">
                2
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-3">Get Verified</h3>
                <p className="text-gray-600">
                  Every car undergoes OBD-II scanning at certified workshops. View complete diagnostic reports.
                </p>
              </div>
            </div>

            <div className="text-center">
              <div className="bg-blue-600 text-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold shadow-lg">
                3
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <CheckCircle className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-3">Buy with Confidence</h3>
                <p className="text-gray-600">
                  Complete documentation, transparent pricing, and AI valuation ensure you get the best deal.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Vehicle Scanning & Verification
            </h2>
            <p className="text-xl text-gray-600 mb-2">Our 7-Step OBD-II Verification Process</p>
            <button
              onClick={() => onNavigate('verification')}
              className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold"
            >
              <span>Learn More About Verification</span>
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Upload, title: 'Upload Details', desc: 'Add car info & photos' },
              { icon: MapPin, title: 'Find Workshop', desc: 'Choose nearby centers' },
              { icon: Calendar, title: 'Book Scanning', desc: 'Schedule appointment' },
              { icon: Wrench, title: 'OBD-II Scan', desc: 'Professional diagnostic' },
              { icon: FileCheck, title: 'Get Report', desc: 'Detailed scan results' },
              { icon: Award, title: 'Verification', desc: 'Certified by workshop' },
              { icon: TrendingUp, title: 'Higher Value', desc: 'Increased trust & price' },
              { icon: CheckCircle, title: 'List & Sell', desc: 'Verified badge' },
            ].map((step, index) => (
              <div key={index} className="bg-gradient-to-br from-blue-50 to-white rounded-xl p-6 border border-blue-100 hover:shadow-lg transition-shadow">
                <div className="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold mb-4">
                  {index + 1}
                </div>
                <step.icon className="h-10 w-10 text-blue-600 mb-3" />
                <h3 className="font-bold text-gray-900 mb-2">{step.title}</h3>
                <p className="text-sm text-gray-600">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {workshops.length > 0 && (
        <div className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Certified Partner Workshops</h2>
              <p className="text-xl text-gray-600">Trusted service centers for vehicle scanning & maintenance</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {workshops.map((workshop) => (
                <div
                  key={workshop.id}
                  className="bg-white rounded-xl shadow-md p-6 hover:shadow-xl transition-shadow cursor-pointer"
                  onClick={() => onNavigate('workshops')}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <Wrench className="h-6 w-6 text-blue-600" />
                    </div>
                    {workshop.is_verified && (
                      <div className="bg-green-100 text-green-600 px-2 py-1 rounded-full text-xs font-semibold">
                        Verified
                      </div>
                    )}
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">{workshop.name}</h3>
                  <p className="text-sm text-gray-600 mb-3">{workshop.city}, {workshop.state}</p>
                  <div className="flex items-center space-x-1 text-yellow-500 mb-2">
                    <Star className="h-4 w-4 fill-current" />
                    <span className="text-sm font-semibold text-gray-900">{workshop.rating.toFixed(1)}</span>
                    <span className="text-xs text-gray-500">({workshop.total_reviews})</span>
                  </div>
                  <p className="text-xs text-gray-500">{workshop.services.slice(0, 2).join(', ')}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {testimonials.length > 0 && (
        <div className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">What Our Customers Say</h2>
              <p className="text-xl text-gray-600">Real stories from real people</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {testimonials.map((testimonial) => (
                <div key={testimonial.id} className="bg-gray-50 rounded-xl p-8 hover:shadow-lg transition-shadow">
                  <div className="flex items-center space-x-1 text-yellow-500 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-6 italic">"{testimonial.comment}"</p>
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                      {testimonial.user_name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{testimonial.user_name}</p>
                      <p className="text-sm text-gray-500">Verified Buyer</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="py-20 bg-gradient-to-br from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Find Your Dream Car?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of happy customers who found their perfect ride with WheelQuest AutoHub
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <button
              onClick={() => onNavigate('used-cars')}
              className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-lg"
            >
              Browse Cars
            </button>
            <button
              onClick={() => onNavigate('sell-car')}
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors text-lg"
            >
              Sell Your Car
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
