export interface Profile {
  id: string;
  full_name: string;
  phone: string;
  role: 'buyer' | 'seller' | 'workshop' | 'admin';
  avatar_url: string;
  location: string;
  created_at: string;
  updated_at: string;
}

export interface Workshop {
  id: string;
  user_id: string;
  name: string;
  description: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
  email: string;
  services: string[];
  rating: number;
  total_reviews: number;
  is_verified: boolean;
  is_active: boolean;
  latitude: number;
  longitude: number;
  image_url: string;
  created_at: string;
  updated_at: string;
}

export interface Car {
  id: string;
  seller_id: string;
  vin?: string;
  brand: string;
  model: string;
  variant: string;
  year: number;
  fuel_type: string;
  transmission: string;
  mileage: number;
  owners: number;
  price: number;
  ai_estimated_price: number;
  condition: string;
  body_type: string;
  color: string;
  engine_capacity: string;
  power: string;
  torque: string;
  seating_capacity: number;
  features: string[];
  description: string;
  city: string;
  state: string;
  images: string[];
  is_verified: boolean;
  verified_by?: string;
  verification_date?: string;
  is_active: boolean;
  listing_type: 'new' | 'used';
  views: number;
  created_at: string;
  updated_at: string;
}

export interface Booking {
  id: string;
  user_id: string;
  car_id: string;
  workshop_id: string;
  booking_date: string;
  booking_time: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface ScanReport {
  id: string;
  car_id: string;
  workshop_id: string;
  booking_id?: string;
  vin: string;
  dtc_codes: string[];
  scan_data: Record<string, unknown>;
  technician_name: string;
  technician_notes: string;
  overall_status: 'excellent' | 'good' | 'fair' | 'poor';
  report_url: string;
  created_at: string;
}

export interface Testimonial {
  id: string;
  user_id?: string;
  user_name: string;
  user_avatar: string;
  rating: number;
  comment: string;
  car_id?: string;
  is_featured: boolean;
  created_at: string;
}

export interface CarNews {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  author: string;
  category: string;
  image_url: string;
  tags: string[];
  views: number;
  is_published: boolean;
  published_at: string;
  created_at: string;
  updated_at: string;
}
