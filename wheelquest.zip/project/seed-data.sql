-- Sample data for WheelQuest AutoHub

-- Insert sample workshops
INSERT INTO workshops (name, description, address, city, state, pincode, phone, email, services, rating, total_reviews, is_verified, is_active, latitude, longitude)
VALUES
('AutoCare Professional', 'Leading diagnostic center with state-of-the-art OBD-II equipment', '123 MG Road', 'Mumbai', 'Maharashtra', '400001', '+91-9876543210', 'contact@autocare.com', ARRAY['OBD-II Scanning', 'Engine Diagnostics', 'General Service', 'AC Repair'], 4.8, 156, true, true, 19.0760, 72.8777),
('Precision Motors Workshop', 'Expert technicians specializing in car diagnostics and verification', '45 Brigade Road', 'Bangalore', 'Karnataka', '560001', '+91-9876543211', 'info@precisionmotors.com', ARRAY['OBD-II Scanning', 'Transmission Check', 'Brake Service', 'Electrical Repair'], 4.7, 203, true, true, 12.9716, 77.5946),
('TechDrive Service Center', 'Modern facility with certified mechanics and advanced tools', '78 Park Street', 'Kolkata', 'West Bengal', '700016', '+91-9876543212', 'support@techdrive.com', ARRAY['OBD-II Scanning', 'Complete Diagnostics', 'Paint & Body', 'Detailing'], 4.9, 89, true, true, 22.5726, 88.3639),
('Elite Auto Solutions', 'Premium service center for all makes and models', '56 Connaught Place', 'Delhi', 'Delhi', '110001', '+91-9876543213', 'hello@eliteauto.com', ARRAY['OBD-II Scanning', 'Engine Overhaul', 'Suspension Work', 'Wheel Alignment'], 4.6, 178, true, true, 28.6139, 77.2090);

-- Insert sample testimonials
INSERT INTO testimonials (user_name, user_avatar, rating, comment, is_featured)
VALUES
('Rajesh Kumar', '', 5, 'WheelQuest made selling my car so easy! The AI price estimation was spot-on and the OBD-II verification gave buyers complete confidence. Sold in just 2 weeks!', true),
('Priya Sharma', '', 5, 'I bought a verified car from WheelQuest and the transparency was amazing. Full diagnostic report helped me make an informed decision. Highly recommended!', true),
('Amit Patel', '', 5, 'The verification process is thorough and professional. As a workshop partner, the platform makes it easy to manage appointments and upload reports.', true);

-- Insert sample car news
INSERT INTO car_news (title, slug, excerpt, content, author, category, image_url, tags, is_published)
VALUES
('Top 5 Things to Check Before Buying a Used Car', 'top-5-things-check-buying-used-car', 'Essential checklist for used car buyers', 'When buying a used car, it''s crucial to conduct thorough inspections. Here are the top 5 things you should always check: 1. Engine condition and performance 2. Body condition and paint quality 3. Interior wear and tear 4. Service history and maintenance records 5. OBD-II diagnostic scan results. At WheelQuest AutoHub, all our verified cars come with complete diagnostic reports, giving you peace of mind.', 'WheelQuest Editorial Team', 'buying-guide', '', ARRAY['used cars', 'buying guide', 'tips'], true),
('Understanding OBD-II Diagnostic Codes', 'understanding-obd2-diagnostic-codes', 'Complete guide to vehicle diagnostic codes', 'OBD-II (On-Board Diagnostics II) is a standardized system that allows external electronics to interface with a car''s computer system. Understanding these codes can help you identify potential issues early. Common codes include P0 (powertrain), B0 (body), C0 (chassis), and U0 (network). WheelQuest''s verification process includes comprehensive OBD-II scanning to ensure transparency.', 'WheelQuest Editorial Team', 'maintenance', '', ARRAY['OBD-II', 'diagnostics', 'maintenance'], true),
('Why Car Verification Matters in 2024', 'why-car-verification-matters-2024', 'The importance of proper vehicle verification', 'In today''s used car market, verification has become more important than ever. With advanced diagnostic tools like OBD-II scanners, buyers can now access detailed information about a vehicle''s health. WheelQuest AutoHub pioneered the verified car marketplace in India, ensuring every listed vehicle undergoes professional inspection at certified workshops.', 'WheelQuest Editorial Team', 'news', '', ARRAY['verification', 'used cars', 'marketplace'], true);
