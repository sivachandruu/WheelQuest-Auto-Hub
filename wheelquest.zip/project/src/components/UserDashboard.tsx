import { useState, useEffect } from 'react';
import { Car, Calendar, FileCheck, Settings, Plus } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Car as CarType, Booking } from '../types';

interface UserDashboardProps {
  onNavigate: (page: string) => void;
}

export function UserDashboard({ onNavigate }: UserDashboardProps) {
  const { user, profile } = useAuth();
  const [myCars, setMyCars] = useState<CarType[]>([]);
  const [myBookings, setMyBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchMyCars();
      fetchMyBookings();
    }
  }, [user]);

  const fetchMyCars = async () => {
    const { data } = await supabase
      .from('cars')
      .select('*')
      .eq('seller_id', user?.id)
      .order('created_at', { ascending: false });

    if (data) setMyCars(data);
  };

  const fetchMyBookings = async () => {
    const { data } = await supabase
      .from('bookings')
      .select('*')
      .eq('user_id', user?.id)
      .order('created_at', { ascending: false });

    if (data) setMyBookings(data);
    setLoading(false);
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800',
      confirmed: 'bg-blue-100 text-blue-800',
      completed: 'bg-green-100 text-green-800',
      cancelled: 'bg-red-100 text-red-800',
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">My Dashboard</h1>
          <p className="text-gray-600">Welcome back, {profile?.full_name || 'User'}!</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <Car className="h-10 w-10 text-blue-600" />
              <span className="text-3xl font-bold text-gray-900">{myCars.length}</span>
            </div>
            <h3 className="text-gray-600 font-semibold">My Cars Listed</h3>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <Calendar className="h-10 w-10 text-green-600" />
              <span className="text-3xl font-bold text-gray-900">{myBookings.length}</span>
            </div>
            <h3 className="text-gray-600 font-semibold">Total Bookings</h3>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <FileCheck className="h-10 w-10 text-purple-600" />
              <span className="text-3xl font-bold text-gray-900">
                {myCars.filter((c) => c.is_verified).length}
              </span>
            </div>
            <h3 className="text-gray-600 font-semibold">Verified Cars</h3>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">My Cars</h2>
            <button
              onClick={() => onNavigate('sell-car')}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
            >
              <Plus className="h-5 w-5" />
              <span>Add New Car</span>
            </button>
          </div>

          {myCars.length === 0 ? (
            <div className="text-center py-12">
              <Car className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">You haven't listed any cars yet</p>
              <button
                onClick={() => onNavigate('sell-car')}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
              >
                List Your First Car
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {myCars.map((car) => (
                <div
                  key={car.id}
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-1">
                        {car.brand} {car.model} {car.variant}
                      </h3>
                      <p className="text-gray-600 text-sm mb-2">
                        {car.year} • {car.mileage.toLocaleString()} km • {car.fuel_type}
                      </p>
                      <div className="flex items-center space-x-3">
                        <span className="text-lg font-bold text-gray-900">
                          ₹{(car.price / 100000).toFixed(2)}L
                        </span>
                        <span
                          className={`text-xs px-2 py-1 rounded-full ${
                            car.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {car.is_active ? 'Active' : 'Inactive'}
                        </span>
                        {car.is_verified && (
                          <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800 flex items-center space-x-1">
                            <FileCheck className="h-3 w-3" />
                            <span>Verified</span>
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      {!car.is_verified && (
                        <button
                          onClick={() => onNavigate('verification')}
                          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm"
                        >
                          Get Verified
                        </button>
                      )}
                      <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors text-sm flex items-center space-x-1">
                        <Settings className="h-4 w-4" />
                        <span>Manage</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">My Bookings</h2>

          {myBookings.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">No bookings yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {myBookings.map((booking) => (
                <div
                  key={booking.id}
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-gray-900 mb-2">Scanning Appointment</h3>
                      <div className="text-sm text-gray-600 space-y-1">
                        <p>
                          <span className="font-semibold">Date:</span> {booking.booking_date}
                        </p>
                        <p>
                          <span className="font-semibold">Time:</span> {booking.booking_time}
                        </p>
                        {booking.notes && (
                          <p>
                            <span className="font-semibold">Notes:</span> {booking.notes}
                          </p>
                        )}
                      </div>
                    </div>
                    <span className={`text-xs px-3 py-1 rounded-full font-semibold ${getStatusColor(booking.status)}`}>
                      {booking.status.toUpperCase()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
