import { useState } from 'react';
import { Upload, TrendingUp, CheckCircle, Sparkles } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface SellCarProps {
  onNavigate: (page: string) => void;
}

export function SellCar({ onNavigate }: SellCarProps) {
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [estimatedPrice, setEstimatedPrice] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    brand: '',
    model: '',
    variant: '',
    year: new Date().getFullYear(),
    fuel_type: 'Petrol',
    transmission: 'Manual',
    mileage: 0,
    owners: 1,
    color: '',
    city: '',
    state: '',
    description: '',
    body_type: 'Sedan',
    engine_capacity: '',
    condition: 'used',
  });

  const brands = ['Maruti Suzuki', 'Hyundai', 'Tata', 'Mahindra', 'Honda', 'Toyota', 'Kia', 'MG', 'Volkswagen', 'Skoda'];
  const fuelTypes = ['Petrol', 'Diesel', 'CNG', 'Electric', 'Hybrid'];
  const bodyTypes = ['Sedan', 'SUV', 'Hatchback', 'Compact SUV', 'MUV', 'Coupe', 'Convertible'];
  const transmissionTypes = ['Manual', 'Automatic', 'AMT', 'CVT', 'DCT'];

  const handleInputChange = (field: string, value: string | number) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const calculateAIPrice = () => {
    setLoading(true);

    setTimeout(() => {
      const basePrice = 800000;
      const yearFactor = (2024 - formData.year) * 30000;
      const mileageFactor = (formData.mileage / 10000) * 15000;
      const ownerFactor = (formData.owners - 1) * 25000;

      let brandMultiplier = 1;
      if (['Toyota', 'Honda'].includes(formData.brand)) brandMultiplier = 1.2;
      if (['Maruti Suzuki', 'Hyundai'].includes(formData.brand)) brandMultiplier = 1.1;

      let fuelMultiplier = 1;
      if (formData.fuel_type === 'Diesel') fuelMultiplier = 1.15;
      if (formData.fuel_type === 'Electric') fuelMultiplier = 1.3;

      let transmissionBonus = 0;
      if (formData.transmission === 'Automatic') transmissionBonus = 50000;

      const calculatedPrice = Math.max(
        (basePrice - yearFactor - mileageFactor - ownerFactor) * brandMultiplier * fuelMultiplier + transmissionBonus,
        100000
      );

      setEstimatedPrice(Math.round(calculatedPrice / 10000) * 10000);
      setLoading(false);
      setStep(2);
    }, 2000);
  };

  const handleSubmit = async () => {
    if (!user) {
      onNavigate('signin');
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase.from('cars').insert({
        seller_id: user.id,
        brand: formData.brand,
        model: formData.model,
        variant: formData.variant,
        year: formData.year,
        fuel_type: formData.fuel_type,
        transmission: formData.transmission,
        mileage: formData.mileage,
        owners: formData.owners,
        price: estimatedPrice || 0,
        ai_estimated_price: estimatedPrice || 0,
        condition: formData.condition,
        body_type: formData.body_type,
        color: formData.color,
        engine_capacity: formData.engine_capacity,
        description: formData.description,
        city: formData.city,
        state: formData.state,
        listing_type: 'used',
        is_active: true,
        images: [],
      });

      if (error) throw error;

      setStep(3);
    } catch (error) {
      console.error('Error listing car:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Sell Your Car</h1>
          <p className="text-xl text-gray-600">Get AI-powered price estimation in seconds</p>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <div className="flex justify-between mb-8">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                    step >= s ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  {s}
                </div>
                {s < 3 && (
                  <div className={`flex-1 h-1 mx-2 ${step > s ? 'bg-blue-600' : 'bg-gray-200'}`}></div>
                )}
              </div>
            ))}
          </div>

          {step === 1 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Enter Car Details</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Brand</label>
                  <select
                    value={formData.brand}
                    onChange={(e) => handleInputChange('brand', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select Brand</option>
                    {brands.map((brand) => (
                      <option key={brand} value={brand}>
                        {brand}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Model</label>
                  <input
                    type="text"
                    value={formData.model}
                    onChange={(e) => handleInputChange('model', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., Swift, Creta"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Variant</label>
                  <input
                    type="text"
                    value={formData.variant}
                    onChange={(e) => handleInputChange('variant', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., VXI, SX"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Year</label>
                  <input
                    type="number"
                    value={formData.year}
                    onChange={(e) => handleInputChange('year', parseInt(e.target.value))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="1990"
                    max={new Date().getFullYear()}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Fuel Type</label>
                  <select
                    value={formData.fuel_type}
                    onChange={(e) => handleInputChange('fuel_type', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {fuelTypes.map((fuel) => (
                      <option key={fuel} value={fuel}>
                        {fuel}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Transmission</label>
                  <select
                    value={formData.transmission}
                    onChange={(e) => handleInputChange('transmission', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {transmissionTypes.map((trans) => (
                      <option key={trans} value={trans}>
                        {trans}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Mileage (km)</label>
                  <input
                    type="number"
                    value={formData.mileage}
                    onChange={(e) => handleInputChange('mileage', parseInt(e.target.value))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Number of Owners</label>
                  <input
                    type="number"
                    value={formData.owners}
                    onChange={(e) => handleInputChange('owners', parseInt(e.target.value))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="1"
                    max="5"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Body Type</label>
                  <select
                    value={formData.body_type}
                    onChange={(e) => handleInputChange('body_type', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {bodyTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Color</label>
                  <input
                    type="text"
                    value={formData.color}
                    onChange={(e) => handleInputChange('color', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., White, Black"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">City</label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => handleInputChange('city', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., Mumbai"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">State</label>
                  <input
                    type="text"
                    value={formData.state}
                    onChange={(e) => handleInputChange('state', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., Maharashtra"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={4}
                  placeholder="Tell us more about your car..."
                ></textarea>
              </div>

              <button
                onClick={calculateAIPrice}
                disabled={!formData.brand || !formData.model || !formData.city || loading}
                className="w-full bg-blue-600 text-white py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:bg-blue-400 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                <Sparkles className="h-5 w-5" />
                <span>{loading ? 'Calculating...' : 'Get AI Price Estimation'}</span>
              </button>
            </div>
          )}

          {step === 2 && estimatedPrice && (
            <div className="space-y-6">
              <div className="text-center mb-8">
                <TrendingUp className="h-16 w-16 text-green-600 mx-auto mb-4" />
                <h2 className="text-3xl font-bold text-gray-900 mb-2">AI Estimated Price</h2>
                <p className="text-gray-600">Based on market analysis and car condition</p>
              </div>

              <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-xl p-8 text-center border-2 border-green-200">
                <p className="text-gray-600 mb-2">Your Car is Worth</p>
                <p className="text-5xl font-bold text-green-600 mb-4">
                  ₹{(estimatedPrice / 100000).toFixed(2)} Lakhs
                </p>
                <p className="text-sm text-gray-500">
                  Price Range: ₹{((estimatedPrice * 0.9) / 100000).toFixed(2)}L - ₹
                  {((estimatedPrice * 1.1) / 100000).toFixed(2)}L
                </p>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="font-bold text-gray-900 mb-4">AI Analysis Factors:</h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Brand reputation and market demand</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Vehicle age and depreciation</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Mileage and usage patterns</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Ownership history</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Fuel type and transmission preferences</span>
                  </li>
                </ul>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                <h3 className="font-bold text-yellow-900 mb-2 flex items-center space-x-2">
                  <Upload className="h-5 w-5" />
                  <span>Increase Your Car Value by 15-20%!</span>
                </h3>
                <p className="text-sm text-yellow-800">
                  Get your car OBD-II verified from our certified workshops to increase buyer trust and resale value.
                </p>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={loading}
                  className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:bg-blue-400"
                >
                  {loading ? 'Listing Car...' : 'List My Car'}
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="text-center py-8">
              <CheckCircle className="h-20 w-20 text-green-600 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Car Listed Successfully!</h2>
              <p className="text-gray-600 mb-8">
                Your car is now live on WheelQuest AutoHub. Get it verified to attract more buyers!
              </p>
              <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
                <button
                  onClick={() => onNavigate('verification')}
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                >
                  Get Car Verified
                </button>
                <button
                  onClick={() => onNavigate('user-dashboard')}
                  className="bg-gray-200 text-gray-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
                >
                  Go to Dashboard
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
