import { Car, Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Car className="h-8 w-8 text-blue-500" />
              <span className="text-xl font-bold text-white">WheelQuest</span>
            </div>
            <p className="text-sm mb-4">
              India's most trusted platform for verified cars with OBD-II scanning and AI price estimation.
            </p>
            <div className="flex space-x-4">
              <Facebook className="h-5 w-5 cursor-pointer hover:text-blue-500 transition-colors" />
              <Twitter className="h-5 w-5 cursor-pointer hover:text-blue-400 transition-colors" />
              <Instagram className="h-5 w-5 cursor-pointer hover:text-pink-500 transition-colors" />
              <Youtube className="h-5 w-5 cursor-pointer hover:text-red-500 transition-colors" />
            </div>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => onNavigate('new-cars')} className="hover:text-blue-500 transition-colors">
                  New Cars
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('used-cars')} className="hover:text-blue-500 transition-colors">
                  Used Cars
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('sell-car')} className="hover:text-blue-500 transition-colors">
                  Sell Your Car
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('verification')} className="hover:text-blue-500 transition-colors">
                  Car Verification
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('workshops')} className="hover:text-blue-500 transition-colors">
                  Workshops
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Tools & Resources</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => onNavigate('emi-calculator')} className="hover:text-blue-500 transition-colors">
                  EMI Calculator
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('compare')} className="hover:text-blue-500 transition-colors">
                  Compare Cars
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('news')} className="hover:text-blue-500 transition-colors">
                  Car News & Tips
                </button>
              </li>
              <li>
                <button className="hover:text-blue-500 transition-colors">Car Reviews</button>
              </li>
              <li>
                <button className="hover:text-blue-500 transition-colors">Buying Guide</button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start space-x-2">
                <MapPin className="h-5 w-5 flex-shrink-0 mt-0.5" />
                <span>123 Auto Street, Mumbai, Maharashtra 400001</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone className="h-5 w-5 flex-shrink-0" />
                <span>+91 1800-123-4567</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="h-5 w-5 flex-shrink-0" />
                <span>support@wheelquest.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm">
              © 2024 WheelQuest AutoHub. All rights reserved.
            </p>
            <div className="flex space-x-6 text-sm">
              <button className="hover:text-blue-500 transition-colors">Privacy Policy</button>
              <button className="hover:text-blue-500 transition-colors">Terms of Service</button>
              <button className="hover:text-blue-500 transition-colors">Cookie Policy</button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
