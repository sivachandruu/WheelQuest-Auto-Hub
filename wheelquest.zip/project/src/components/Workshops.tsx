import { useState, useEffect } from 'react';
import { Wrench, Star, MapPin, Phone, Mail, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Workshop } from '../types';

export function Workshops() {
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchWorkshops();
  }, []);

  const fetchWorkshops = async () => {
    const { data } = await supabase
      .from('workshops')
      .select('*')
      .eq('is_verified', true)
      .eq('is_active', true)
      .order('rating', { ascending: false });

    if (data) setWorkshops(data);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading workshops...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Wrench className="h-16 w-16 text-blue-600 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Certified Partner Workshops</h1>
          <p className="text-xl text-gray-600">
            Trusted service centers for OBD-II scanning and vehicle maintenance
          </p>
        </div>

        {workshops.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl">
            <p className="text-gray-600">No workshops available at the moment</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {workshops.map((workshop) => (
              <div
                key={workshop.id}
                className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow overflow-hidden"
              >
                <div className="h-48 bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                  {workshop.image_url ? (
                    <img
                      src={workshop.image_url}
                      alt={workshop.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Wrench className="h-20 w-20 text-blue-600" />
                  )}
                </div>

                <div className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="text-xl font-bold text-gray-900">{workshop.name}</h3>
                    {workshop.is_verified && (
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                    )}
                  </div>

                  <div className="flex items-center space-x-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(workshop.rating)
                            ? 'text-yellow-500 fill-current'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                    <span className="text-sm font-semibold text-gray-900 ml-2">
                      {workshop.rating.toFixed(1)}
                    </span>
                    <span className="text-sm text-gray-500">({workshop.total_reviews})</span>
                  </div>

                  <p className="text-sm text-gray-600 mb-4 line-clamp-2">{workshop.description}</p>

                  <div className="space-y-2 text-sm text-gray-700 mb-4">
                    <div className="flex items-start space-x-2">
                      <MapPin className="h-4 w-4 text-gray-400 flex-shrink-0 mt-0.5" />
                      <span className="line-clamp-2">
                        {workshop.address}, {workshop.city}, {workshop.state}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Phone className="h-4 w-4 text-gray-400" />
                      <span>{workshop.phone}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4 text-gray-400" />
                      <span className="truncate">{workshop.email}</span>
                    </div>
                  </div>

                  <div className="border-t border-gray-200 pt-4">
                    <p className="text-xs font-semibold text-gray-600 mb-2">Services Offered:</p>
                    <div className="flex flex-wrap gap-2">
                      {workshop.services.slice(0, 3).map((service, i) => (
                        <span
                          key={i}
                          className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-full"
                        >
                          {service}
                        </span>
                      ))}
                      {workshop.services.length > 3 && (
                        <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                          +{workshop.services.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>

                  <button className="w-full mt-4 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold">
                    Book Appointment
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
